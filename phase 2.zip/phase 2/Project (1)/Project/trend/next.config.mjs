/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: false,
  images: {
    domains: ["prod-img.thesouledstore.com"],
  },
};

export default nextConfig;
