"use client";
import Image from "next/image";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";



const Product = ({ params }) => {
  const [product, setProduct] = useState({});
  const [total, setTotal] = useState(0);
  const [loader, setLoader] = useState(true);
  const [quantity, setQuantity] = useState(1);
  const [loginUser, setLoginUser] = useState("");
  const id = params.id;
  const router = useRouter();

  useEffect(() => {
    const user = JSON.parse(localStorage.getItem("loginUser")) || [];
    setLoginUser(user);
    const fetchProduct = async () => {
      try {
        setLoader(true);
        const response = await fetch(`/api/products/${id}`);
        if (!response.ok) {
          throw new Error('There is some error');
        }
        const newProduct = await response.json();
        setTotal(newProduct.price);
        setProduct(newProduct);
        setLoader(false);
      } catch (error) {
        alert(`${error}`);
        setLoader(false);
      }
    };
    fetchProduct();
  }, []);

  const handlePrice = (event) => {
    const { value } = event.target;
    setQuantity(value);
    let totalPrice = parseFloat(product.price) * parseInt(value);
    if(totalPrice> loginUser.balance)
      {
        alert('Sorry You have insufficient Balance');
        totalPrice= totalPrice -parseFloat(product.price);
        setQuantity(value-1);
        return;
      }
    setTotal(totalPrice);
  };
   
  const handleSaveOrder = async (event) => {
    event.preventDefault();

    try {
      const response = await fetch('/api/order', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          orderDate: new Date().toISOString(),
          totalAmount: total,
          customerId: loginUser.id,
          orderItems: [
            {
              ...product,
              quantity,
            }
          ]
        }),
      });

      const data = await response.json();
      const newBalance = loginUser.balance - total;
      const updatedUser = { ...loginUser, balance: newBalance };
      localStorage.setItem('loginUser', JSON.stringify(updatedUser));
      console.log(data);
      alert('order place successfully')
      router.push('/');
    } catch (error) {
      console.error('Error:', error);
      alert(error)
    }
  };

  return (
    <>
      <main className="checkout-page">
        <div className="login-form-card">
          <h1 className="login-header">Checkout </h1>
          <h3>     Your Current Balance:  ( {loginUser.balance}) </h3>
          <div className="checkout-card" id="product-container">
            <div className="product">
              <img
                className="product-image"
                src={product.image}
                alt={product.title}
                width={200}
                height={200}
              />
            </div>
            <div className="checkout-text">
              <h1 className="margin-tb">Tom &amp; Jerry T-Shirt</h1>
              <form id="checkoutform" onSubmit={handleSaveOrder}>
                <div className="input-container">
                  <label htmlFor="address">House No/Lane No</label>
                  <input className="checkout-input" value={loginUser.shippingAddress} type="text" id="address"  required />
                </div>
                <div className="input-container">
                  <label htmlFor="city">City</label>
                  <input className="checkout-input" type="text" value={loginUser.city} id="city"  required />
                </div>
                <div className="input-container">
                  <label htmlFor="state">Email</label>
                  <input className="checkout-input" type="text" value={loginUser.email} id="state" disabled />
                </div>
               
                <div className="input-container">
                  <label htmlFor="quantity">Quantity</label>
                  <input
                    className="checkout-input"
                    type="number"
                    name="quantity"
                    value={quantity}
                    min="1"
                    max={product.stock}
                    id="quantity"
                    onChange={handlePrice}
                  />
                </div>
                <p className="margin-tb fw-bold">Price: ${product.price}</p>
                <hr className="margin-tb" />
                <p className="margin-tb fw-bold" id="total">
                  Total: ${total}
                </p>
                <button type="submit" className="login-button w-full" id="checkout-button">
                  Checkout
                </button>
              </form>
            </div>
          </div>
        </div>
      </main>
    </>
  );
};

export default Product;



