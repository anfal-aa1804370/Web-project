export default function Nav(){
    return <>
      <header className="header">
        <div>
            <h3 className="nav-brand" onclick="gotoHome()">Trend</h3><span id="user-type"></span>
        </div>
        <nav className="nav">
            <ul className="nav-items" id="nav-items">
                <li className="nav-item active" id="home"><a href="/">Home</a></li>
                <li className="nav-item" style="display: none;" id="orders"><a href="orders.html">Orders</a></li>
                <li className="nav-item" style="display: none;" id="products"><a href="products.html">Products</a></li>
                <li className="nav-item" id="login"><a href="login.html">Login</a></li>
                <li className="nav-item" id="profile" style="display: none;"><a href="profile.html">Profile</a></li>
                <li className="nav-item" style="display: none;" id="logout" onclick="logout()"><a href="#">Logout</a></li>
            </ul>
        </nav>
        <div className="hamburger">
            <span id="openHam">&#9776;</span>
            <span id="closeHam">&#x2716;</span>
        </div>
    </header>
    </>
}