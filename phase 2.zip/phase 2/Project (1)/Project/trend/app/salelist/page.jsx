"use client";
import Image from "next/image";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { useRouter } from "next/navigation";

export default function Order({params}){
    const [orders, setOrders] = useState({});
    const [loader, setLoader] = useState(true);
    const router = useRouter();
  
    useEffect(() => {
      const getAllSoldProductBySellerId = async () => {
        try {
          setLoader(true)
          const user = JSON.parse(localStorage.getItem("loginUser")) || null;
            if (user) {
                const sellerId = user.id;
            const response = await fetch(`/api/orderlist/${sellerId}`);
            if (!response.ok) {
              throw new Error("Failed to fetch purchases");
            }
            const data = await response.json();
            setOrders(data);
            setLoader(false)
          }
        } catch (error) {
          alert( error);
          setLoader(false)
        }
      };
  
      getAllSoldProductBySellerId();
    }, []);
  
   
    return <>
    
    <main>
    <h1 className="login-header">My Products</h1>
       
    <section className="table-section" id="table">
      <h1></h1>
        <table>
            <thead>
                <tr>
                 
                    <th>Image</th>
                    <th>Title</th>
                    <th>Price</th>
                   
                    
                </tr>
            </thead>
            <tbody id="table-body">
              {loader ? (
                <tr>
                  <td colSpan="5"><div
          style={{ width: "100%", display: "flex", justifyContent: "center" }}
        >
          <div class="loader"></div>
        </div></td>
                </tr>
              ) : 
                (
                
                 orders.map((order, index) => {
                    console.log(`Order ${index + 1}:`);
                    console.log(`Order Date: ${order.orderDate}`);
                    console.log(`Total Amount: ${order.totalAmount}`);
                    console.log(`Customer: ${order.customer.username}`);
                    
                    order.orderItems.map((orderItem, itemIndex) => {
                      console.log(`  Order Item ${itemIndex + 1}:`);
                      console.log(`  Product: ${orderItem.product.title}`);
                      console.log(`  Quantity: ${orderItem.quantity}`);
                    });
                  })
             
             
                )             
             }
            </tbody>
        </table>
    </section>
    </main>
    </>
}