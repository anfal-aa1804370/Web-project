"use client";
import Image from "next/image";
import { useEffect, useState } from "react";
import { toast } from "sonner";

export default function Order({params}){
    const [orders, setOrders] = useState({});
    const [loader, setLoader] = useState(true);
   
  
    useEffect(() => {
      const getAllOrdersbyuser = async () => {
        try {
          setLoader(true)
          const user = JSON.parse(localStorage.getItem("loginUser")) || null;
            if (user) {
            const response = await fetch(`/api/order/${user.id}`);
            if (!response.ok) {
              throw new Error("Failed to fetch purchases");
            }
            const data = await response.json();
            setOrders(data);
            setLoader(false)
          }
        } catch (error) {
          toast.error("Got error while getting orders:", error);
          setLoader(false)
        }
      };
  
      getAllOrdersbyuser();
    }, []);
  
    return <>
    
    <main>
    <h3>Purchase History</h3>
    <section className="table-section" id="table">
      
        <table>
            <thead>
                <tr>
                 
                    <th>Date</th>
                    <th>Product Name</th>
                    <th>Quantity</th>
                    <th>Pice</th>
                    <th>Total</th>
                    
                </tr>
            </thead>
            <tbody id="table-body">
              {loader ? (
                <tr>
                  <td colSpan="5">Loading...</td>
                </tr>
              ) : (
                orders.map(order => (
                  <tr key={order.id} style={{textAlign:"center"}}>
                    <td>{new Date(order.orderDate).toLocaleDateString('en-US')}</td>
                    <td>
                    {order.orderItems.map(orderItem => (
                  <div key={orderItem.id}>
                    Product Title: {orderItem.product.title}
                  </div>
                ))}
                      </td>
                    <td>{order.orderItems.reduce((acc, item) => acc + item.quantity, 0)}</td>
                    <td>${order.totalAmount.toFixed(2)}</td>
                    <td>${order.orderItems.reduce((acc, item) => acc + (item.quantity * item.product.price), 0).toFixed(2)}</td>
                    
                  </tr>
                ))
              )}
            </tbody>
        </table>
    </section>
    </main>
    </>
}