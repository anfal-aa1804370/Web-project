import Order from "@/app/Repository/Order";

export async function GET(req) {
  const data = await Order.getAllOrders();
  return new Response(data);
}

export async function POST(request) {
  const orderData = await request.json();
  console.log(orderData);
  const order = await Order.saveOrder(orderData);
  return Response.json(order, { status: 200 });
}
