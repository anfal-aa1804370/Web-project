import Order from "@/app/Repository/Order";
export async function GET(req, { params }) {
  const id = params.id;
  console.log(id);
  const data = await Order.getOrderById(id);
  return new Response(data);
}
