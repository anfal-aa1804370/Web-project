import User from "@/app/Repository/user";

export async function GET(req, { params }) {
  const id = params.id;
  console.log(id);
  const result = await User.getUserById(parseInt(id));
  return new Response(result);
}
