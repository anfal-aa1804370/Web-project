import User from "@/app/Repository/user";

export async function GET(req) {
  const result = await User.getAllUser();
  return new Response(result);
}

export async function POST(request) {
  const user = await request.json();
  console.log(user);
  const result = await User.checkUser(user);
  return new Response(result);
}
