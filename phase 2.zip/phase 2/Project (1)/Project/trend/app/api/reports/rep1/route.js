import user from "@/app/Repository/user";
export async function GET(req) {
  const data = await user.getTotalNoofCustomers();
  return new Response(data);
}
