import products from "@/app/Repository/products";

export async function GET(req) {
  const data = await products.getAllProducts();
  return new Response(data);
}

export async function POST(request) {
  const product = await request.json();
  console.log(product);
  const data = await products.saveProduct(product);
  return new Response(data);
}
