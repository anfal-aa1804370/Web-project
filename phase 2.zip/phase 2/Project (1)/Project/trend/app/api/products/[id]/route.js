import products from "@/app/Repository/products";

export async function GET(req, { params }) {
  const id = params.id;
  console.log(params.id);
  const product = await products.getProductById(id);
  return new Response(product);
}

export async function PUT(req, { params }) {
  const productId = parseInt(params.id);
  const productUpdate = await req.json();
  const updatedProduct = await products.updateProduct(productId, productUpdate);
  return Response.json(updatedProduct, { status: 200 });
}
