import products from "@/app/Repository/products";

export async function GET(req, { params }) {
  const sellerId = params.sellerId;
  console.log(params.sellerId);
  console.log("iam here ");
  const product = await products.getProductBySellerId(sellerId);
  return new Response(product);
}
