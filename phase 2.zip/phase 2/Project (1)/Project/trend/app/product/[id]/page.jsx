"use client";
import Image from "next/image";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

export default function Product({params}){
    const [product, setProduct] = useState({});
    const [loader, setLoader] = useState(true);
    const [loginUser, setLoginUser] = useState({});
    const route = useRouter();
 const id = params.id;
 useEffect(() => {
 
    const fetchProduct = async () => {
      
      const user = JSON.parse(localStorage.getItem("loginUser")) || {};
      console.log(user)
      setLoginUser(user);
      try {

        setLoader(true);
        const response = await fetch(`/api/products/${id}`);
        if (!response.ok) {
          throw new Error("There is some error");
        }
        const newProduct = await response.json();
        console.log(newProduct);
        setProduct(newProduct);
        setLoader(false);
      } catch (error) {
        alert(`${error}`);
        setLoader(false);
      }
    };
    fetchProduct();
  }, []);

  const handleUpdate = async () => {
    try {
      const response = await fetch(`/api/products/${product.id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          price: parseInt(product.price),
          stock: parseInt(product.stock),
        }),
      });
      if (!response.ok) {
        throw new Error("Failed to update product");
      }
      alert("Product updated successfully");
      route.push("/");
    } catch (error) {
      alert(error);
    }
  };

  const goToCheck = (prod)=>{  
    route.push(`/checkout/${prod.id}`);      
 }
    return <>
    <main>
    {
        (!loader) ? ( <main className="product-detail-section" id="product-container">
        <div className="product-detail-image-container">
        <Image
                   className="product-detail-image"
                   src={product.image}
                   alt={product.title}
                   width={400}
                   height={450}
                 />
        </div>        
        <div className="product-detail-text">
           <h1 className="product-detail-name">{product.title}</h1>
           <p className="product-detail-description">{product.description}</p>
           
           { loginUser.userType != 'seller' ? (<><p className="product-detail-price"> {product.price}</p>
           <button className="product-detail-buy-button" id="update-button"  onClick={()=>goToCheck(product)}>Buy</button>
         </> ): (
            <div className="input-container">
              <label htmlFor="quantity">Price</label>
              <input className="margin-tb fw-bold" type="number" value={product.price}  onChange={(e) =>
                    setProduct({ ...product, price: e.target.value })
                  } /><br/>
             <label htmlFor="quantity">Stock</label> 
             <input className="margin-tb fw-bold" type="number" value={product.stock}  onChange={(e) =>
                    setProduct({ ...product, stock: e.target.value })
                  } />
             <button className="product-detail-buy-button" id="update-button"  onClick={handleUpdate}>Update</button>
        
            </div>
           )}
           
         </div>
           
       </main>) :(<div
          style={{ width: "100%", display: "flex", justifyContent: "center" }}
        >
          <div className="loader"></div>
        </div>)
    }
    </main>
    </>
}