"use client";
import Image from "next/image";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { useRouter } from "next/navigation";

export default function Order({params}){
    const [orders, setOrders] = useState({});
    const [loader, setLoader] = useState(true);
    const router = useRouter();
  
    useEffect(() => {
      const getAllOrders = async () => {
        try {
          setLoader(true)
          const user = JSON.parse(localStorage.getItem("loginUser")) || null;
            if (user.userType == 'admin') {
             
            const response = await fetch(`/api/order`);
            if (!response.ok) {
              throw new Error("Failed to fetch orders");
              alert('some problem')
            }
            const data = await response.json();
            setOrders(data);
            setLoader(false)
          }
        } catch (error) {
          alert( error);
          setLoader(false)
        }
      };
  
      getAllOrders();
    }, []);
  
    const gotoAddProduct =()=>{
        router.push('/');
    }
    return <>
    
    <main>
    <h1 className="login-header">All Orders</h1>
       
    <section className="table-section" id="table">
      <h1></h1>
        <table>
            <thead>
                <tr>
                 
                    <th>Date</th>
                    <th>Title</th>
                    <th>Price</th>
                    <th>Quantity</th>
                   
                    
                </tr>
            </thead>
            <tbody id="table-body">
              {loader ? (
                <tr>
                  <td colSpan="5"><div
          style={{ width: "100%", display: "flex", justifyContent: "center" }}
        >
          <div class="loader"></div>
        </div></td>
                </tr>
              ) : (
                orders.map((order) => (
                  <tr key={order.id} style={{textAlign:"center"}}>
                    <td>{new Date(order.orderDate).toLocaleDateString()}</td>
                    <td>{order.orderItems[0].product.title}</td>
                    <td>${order.totalAmount}</td>                    
                    <td>{order.orderItems[0].quantity}</td>
                  </tr>
                ))
              )}
            </tbody>
        </table>
    </section>
    </main>
    </>
}