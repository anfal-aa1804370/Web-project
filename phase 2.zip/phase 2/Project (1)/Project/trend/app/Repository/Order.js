import prisma from "../../DB/client.js";
class Order {
  async saveOrder({ orderDate, totalAmount, customerId, orderItems }) {
    try {
      const newOrder = await prisma.order.create({
        data: {
          orderDate,
          totalAmount,
          customerId,
          orderItems: {
            create: orderItems.map((item) => ({
              quantity: parseInt(item.quantity),
              productId: item.id,
            })),
          },
        },

        include: {
          orderItems: true,
        },
      });

      return newOrder;
    } catch (error) {
      throw new Error(`Failed to save order: ${error.message}`);
    }
  }

  async getAllOrders() {
    try {
      const orders = await prisma.order.findMany({
        include: {
          orderItems: {
            include: {
              product: true,
            },
          },
          customer: true,
        },
      });

      return JSON.stringify(orders);
    } catch (error) {
      console.error(error);
      throw error;
    }
  }

  async getOrderById(id) {
    try {
      const orders = await prisma.order.findMany({
        where: {
          customerId: parseInt(id),
        },
        include: {
          orderItems: {
            include: {
              product: true,
            },
          },
          customer: true,
        },
      });

      return JSON.stringify(orders);
    } catch (error) {
      console.error(error);
      throw error;
    }
  }

  async getOrdersBySellerId(sellerId) {
    try {
      const orders = await prisma.order.findMany({
        where: {
          orderItems: {
            some: {
              product: {
                sellerId: parseInt(sellerId),
              },
            },
          },
        },
        include: {
          orderItems: {
            include: {
              product: true,
            },
          },
          customer: true,
        },
      });
      return orders;
    } catch (error) {
      console.error(error);
      throw error;
    }
  }
}

export default new Order();
