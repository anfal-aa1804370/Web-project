import prisma from "../../DB/client.js";
class User {
  async checkUser(obj) {
    const checkedUser = await prisma.user.findFirst({
      where: {
        username: obj.username,
        password: obj.password,
      },
    });

    return JSON.stringify(checkedUser);
  }

  async getAllUser() {
    const users = await prisma.user.findMany();
    return JSON.stringify(users);
  }
  async getUserById(id) {
    const user = await prisma.user.findUnique({
      where: { id: id },
    });

    if (!user) {
      throw new Error(`User not found`);
    }

    return JSON.stringify(user);
  }
  async getTotalNoofCustomers() {
    const totalCustomers = await prisma.user.count({
      where: {
        userType: "customer",
      },
    });

    const totalCustomersFromQatar = await prisma.user.count({
      where: {
        userType: "customer",
        city: "Qatar",
      },
    });

    const totalCustomersNotFromQatar = await prisma.user.count({
      where: {
        userType: "customer",
        NOT: {
          city: "Qatar",
        },
      },
    });

    const totalSellers = await prisma.user.count({
      where: {
        userType: "seller",
      },
    });

    const totalUsers = totalCustomers + totalSellers;
    return JSON.stringify({
      totalCustomers,
      totalCustomersFromQatar,
      totalCustomersNotFromQatar,
      totalSellers,
      totalUsers,
    });
  }
}

export default new User();
