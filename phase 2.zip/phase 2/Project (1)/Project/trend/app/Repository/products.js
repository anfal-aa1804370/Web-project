import prisma from "../../DB/client.js";

class ProductsRepository {
  async getAllProducts() {
    const products = await prisma.Product.findMany();
    return JSON.stringify(products);
  }

  async getProductById(id) {
    const product = await prisma.product.findUnique({
      where: {
        id: parseInt(id),
      },
    });
    return JSON.stringify(product);
  }

  async updateProduct(productId, newpro) {
    const updatedProduct = await prisma.product.update({
      where: { id: productId },
      data: newpro,
    });
    return JSON.stringify(updatedProduct);
  }

  async getProductBySellerId(id) {
    const product = await prisma.product.findMany({
      where: {
        sellerId: parseInt(id),
      },
    });
    return JSON.stringify(product);
  }

  async saveProduct(product) {
    const { title, image, price, stock, description, sellerId } = product;

    const newProduct = await prisma.product.create({
      data: {
        title,
        image,
        price: parseFloat(price),
        stock: parseInt(stock),
        description,
        sellerId: parseInt(sellerId),
      },
    });
    return JSON.stringify(newProduct);
  }
}
export default new ProductsRepository();
