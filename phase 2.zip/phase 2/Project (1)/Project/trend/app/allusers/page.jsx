"use client";
import Image from "next/image";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { useRouter } from "next/navigation";

export default function Order({params}){
    const [users, setUsers] = useState({});
    const [loader, setLoader] = useState(true);
    const router = useRouter();
  
    useEffect(() => {
      const getAllProductBySeller = async () => {
        try {
          setLoader(true)
          const user = JSON.parse(localStorage.getItem("loginUser")) || null;
            if (user.userType == 'admin') {
             
            const response = await fetch(`/api/user`);
            if (!response.ok) {
              throw new Error("Failed to fetch users");
            }
            const data = await response.json();
            setUsers(data);
            setLoader(false)
          }
        } catch (error) {
          alert( error);
          setLoader(false)
        }
      };
  
      getAllProductBySeller();
    }, []);
  
    const gotoAddProduct =()=>{
        router.push('/');
    }
    return <>
    
    <main>
      
    <h1 className="login-header">All Users</h1>
       
    <section className="table-section" id="table">
      <h1></h1>
        <table>
            <thead>
                <tr>
                 
                    <th>User Name</th>
                    <th>Email</th>
                    <th>User Type</th>
                    <th>Address</th>                   
                    
                </tr>
            </thead>
            <tbody id="table-body">
              {loader ? (
                <tr>
                  <td colSpan="5"><div
          style={{ width: "100%", display: "flex", justifyContent: "center" }}
        >
          <div class="loader"></div>
        </div></td>
                </tr>
              ) : (
                users.map(user => (
                  <tr key={user.id} style={{textAlign:"center"}}>
                    <td>{user.username}</td>
                    <td>{user.email}</td>  
                    <td>{user.userType}</td>                 
                    <td>{user.shippingAddress}</td>                   
                    
                  </tr>
                ))
              )}
            </tbody>
        </table>
    </section>
    </main>
    </>
}