"use client";
import Image from "next/image";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { useRouter } from "next/navigation";

export default function Order({params}){
    const [products, setProducts] = useState({});
    const [loader, setLoader] = useState(true);
    const router = useRouter();
  
    useEffect(() => {
      const getAllProductBySeller = async () => {
        try {
          setLoader(true)
          const user = JSON.parse(localStorage.getItem("loginUser")) || null;
            if (user) {
                const sellerId = user.id;
            const response = await fetch(`/api/seller/${sellerId}`);
            if (!response.ok) {
              throw new Error("Failed to fetch purchases");
            }
            const data = await response.json();
            setProducts(data);
            setLoader(false)
          }
        } catch (error) {
          alert("Got error while getting products for :", error);
          setLoader(false)
        }
      };
  
      getAllProductBySeller();
    }, []);
  
    const gotoAddProduct =()=>{
        router.push('/addproduct');
    }
    return <>
    
    <main>
    <h1 className="login-header">My Products</h1>
        <div className="add-button-div" id="add-button">
            <button className="add-button" onClick={gotoAddProduct}>Add product</button>
        </div>
    <section className="table-section" id="table">
      <h1></h1>
        <table>
            <thead>
                <tr>
                 
                    <th>Image</th>
                    <th>Title</th>
                    <th>Price</th>
                   
                    
                </tr>
            </thead>
            <tbody id="table-body">
              {loader ? (
                <tr>
                  <td colSpan="5"><div
          style={{ width: "100%", display: "flex", justifyContent: "center" }}
        >
          <div class="loader"></div>
        </div></td>
                </tr>
              ) : (
                products.map(prod => (
                  <tr key={prod.id} style={{textAlign:"center"}}>
                    <td  style={{width:"50px", height:"70px", marginRight:"10px"}}>
                    <Image
                className="product-image"
                src={prod.image}
                alt={prod.title}
                width={70}
                height={50}
               
              />
                    </td>
                    <td>{prod.title}</td>
                    <td>{prod.price}</td>                   
                    
                  </tr>
                ))
              )}
            </tbody>
        </table>
    </section>
    </main>
    </>
}