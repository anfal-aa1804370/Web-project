"use client";
import Image from "next/image";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { useRouter } from "next/navigation";

export default function Order({params}){
    const [users, setUsers] = useState({});
    const [loader, setLoader] = useState(true);
    const router = useRouter();
  
    useEffect(() => {
      const getAllProductBySeller = async () => {
        try {
          setLoader(true)
          const user = JSON.parse(localStorage.getItem("loginUser")) || null;

            if (user.userType == 'admin') {
             
            const response = await fetch(`/api/reports/rep1`);
            if (!response.ok) {
              throw new Error("Failed to fetch users");
            }
            const data = await response.json();
            setUsers(data);
           
            setLoader(false)
          }
        } catch (error) {
          alert( error);
          setLoader(false)
        }
      };
  
      getAllProductBySeller();
    }, []);
  
    
    return <>
    
    <main>
      
    <h1 className="login-header">Summary ( Statistics ) </h1>
       
    <section className="table-section" id="table">
      <h1></h1>
        <table>
            <thead>
                <tr>
                 
                    <th>No.</th>
                    <th>Description</th>
                    <th>Result</th>
                                    
                    
                </tr>
            </thead>
            <tbody id="table-body">
            
                <tr>
                    <td>1</td>
                    <td>Total No. of Customers</td>
                    <td>{users.totalCustomers}</td>
                </tr>
                <tr>
                    <td>2</td>
                    <td>Total No. of sellers</td>
                    <td>{users.totalSellers}</td>
                </tr>
                <tr>
                    <td>3</td>
                    <td>Total No. of Customers from Qatar</td>
                    <td>{users.totalCustomersFromQatar}</td>
                </tr>
                <tr>
                    <td>4</td>
                    <td>Total No. of Customers outside Qatar</td>
                    <td>{users.totalCustomersNotFromQatar}</td>
                </tr>
                
                
            </tbody>
        </table>
    </section>
    </main>
    </>
}