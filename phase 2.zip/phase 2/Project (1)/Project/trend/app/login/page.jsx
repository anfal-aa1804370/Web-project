"use client";
import { toast } from "sonner";
import Image from "next/image";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
export default function Product({params}){
    const [product, setProduct] = useState({});
    const [loader, setLoader] = useState(true);
    const [formData, setFormData] = useState({ username: "", password: "" });
    const router = useRouter();

    useEffect(() => {
      const user = JSON.parse(localStorage.getItem("loginUser")) || null;
      if(user)
        {
          router.push('/');
        }
    
    }, []);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleVerifyUser = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch("/api/user", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      });
      
      //console.log(response)
      if (!response.ok) {
        throw new Error("Login failed");
      }

      const data = await response.json();
      console.log(data);
      if (!data) {
        alert("user not found");
        throw new Error("User data is empty");
      }
      localStorage.setItem("loginUser", JSON.stringify(data));
      window.location.reload(true);
      
      router.push("/");
    } catch (error) {
      toast.error(error);
    }
  };

   
    return <>
    <main className="login-page">
        <form onSubmit={handleVerifyUser}>
        <div className="login-form-card">
            <h1 className="login-header">Login</h1>
            <div className="login-header-img">
              <img src="images/login.png" alt="" width={200} height={200} />
              
            </div>
          
            <div className="login-form">
                <div className="input-container">
                    <label for="username"  >Username:</label>
                    <div className="input-with-icon">
                        <i className="fa fa-user icon"></i>
                        <input type="text" name="username" id="username" value={formData.username} onChange={handleChange} required />
                    </div>
                </div>
                <div className="input-container">
                    
                    <label for="password">Enter Password:</label>
                    <div className="input-with-icon">
                        <i className="fa fa-lock icon"></i>
                        <input type="password" name="password" id="password" value={formData.password} onChange={handleChange} required />
                    </div>
                </div>
                <button type="submit" className="login-button">Login</button>
            </div>
        </div>
        </form>
    </main>
    
    </>
}