"use client";
import { usePathname } from "next/navigation";
import { useState } from "react";
import { useEffect } from "react";
import "./page.css";
import { Toaster, toast } from "sonner";
import Link from "next/link";
import { useRouter } from "next/navigation";

export default function RootLayout({ children }) {
  const [loginUser, setLoginUser] = useState({});
  const route = useRouter();

  const logOut = () => {
    localStorage.removeItem("loginUser");
    setLoginUser({});
    route.push("/login");
  };

  useEffect(() => {
    const user = JSON.parse(localStorage.getItem("loginUser")) || {};
    setLoginUser(user);
  }, []);

  return (
    <html lang="en">
      <body>
        <header className="header">
          <div>
            <h3 className="nav-brand">Trend</h3>
            <span id="user-type"></span>
          </div>
          <nav className="nav">
            <ul className="nav-items" id="nav-items">
              <li className="nav-item active" id="home">
                <a href="/">Home</a>
              </li>
              {loginUser.userType === "customer" && (
                <Link className="nav-item" href="/orders">
                  Purchase History
                </Link>
              )}
              {loginUser.userType === "seller" && (
                <Link className="nav-item" href="/productlist">
                  Products
                </Link>
              )}
              {loginUser.userType === "admin" && (
                <Link className="nav-item" href="/allproducts">
                  Products
                </Link>
              )}
              {loginUser.userType === "admin" && (
                <Link className="nav-item" href="/allusers">
                  Users
                </Link>
              )}
              {loginUser.userType === "admin" && (
                <Link className="nav-item" href="/allorders">
                  Orders
                </Link>
              )}
              {loginUser.userType === "admin" && (
                <Link className="nav-item" href="/stats">
                  Reports
                </Link>
              )}
              {loginUser.username && (
                <a className="nav-item" href="/">
                  {loginUser.username}
                </a>
              )}

              {loginUser.username ? (
                <a className="nav-item" onClick={logOut}>
                  Logout
                </a>
              ) : (
                <Link className="nav-item" href="/login">
                  Login
                </Link>
              )}
            </ul>
          </nav>
          <div className="hamburger">
            <span id="openHam">&#9776;</span>
            <span id="closeHam">&#x2716;</span>
          </div>
        </header>

        {children}
        <Toaster richColors position="bottom-left" />
        <footer className="footer">
          <p className="copyright">Trend&copy; 2024</p>
        </footer>
      </body>
    </html>
  );
}
