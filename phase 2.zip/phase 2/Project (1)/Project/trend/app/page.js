"use client";
import Image from "next/image";
import styles from "./page.module.css";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
export default function Home() {
  const [products, setProducts] = useState([]);
  const [loginUser, setLoginUser] = useState({});
  const [loader, setLoader] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const route = useRouter();
  useEffect(() => {
    const fetchProducts = async () => {
      try {
        setLoader(true);
        const user = JSON.parse(localStorage.getItem("loginUser")) || {};
        setLoginUser(user);
        let response;
        if (user.userType === "seller") {
          response = await fetch(`/api/seller/${user.id}`);
        } else {
          response = await fetch("/api/products");
        }
        if (!response.ok) {
          throw new Error("There is some error");
        }
        let newProducts = await response.json();
        if (Array.isArray(newProducts)) {
          newProducts = newProducts;
        } else {
          newProducts = [newProducts];
        }
        console.log(newProducts);
        setProducts(newProducts);
        setLoader(false);
      } catch (error) {
        alert(`${error}`);
        setLoader(false);
      }
    };
    fetchProducts();
    const user = JSON.parse(localStorage.getItem("loginUser")) || {};
    setLoginUser(user);
  }, []);

  const handleSearchProduct = (event) => {
    console.log(searchTerm);

    setSearchTerm(event.target.value);
  };

  const filteredProducts = products.filter((product) =>
    product.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleProductDetail = (product) => {
    if (
      loginUser.userType == "admin" ||
      loginUser.userType == "seller" ||
      loginUser.userType == "customer"
    ) {
      route.push(`/product/${product.id}`);
    } else {
      alert("You are not loged in");

      route.push(`/login`);
    }
  };

  return (
    <main>
      <section className="search-container">
        <form classname="form">
          <input
            type="search"
            name="search"
            id="search"
            onInput={handleSearchProduct}
            placeholder="Type to search products"
          />
        </form>
      </section>
      {!loader ? (
        <section className="product-container" id="product-container">
          {filteredProducts.map((product) => (
            <div
              key={product.id}
              className="product"
              onClick={() => handleProductDetail(product)}
            >
              <Image
                className="product-image"
                src={product.image}
                alt={product.title}
                width={200}
                height={200}
              />
              <h1 className="product-name">{product.title}</h1>

              <p className="product-price">Price: ${product.price}</p>
            </div>
          ))}
        </section>
      ) : (
        <div
          style={{ width: "100%", display: "flex", justifyContent: "center" }}
        >
          <div class="loader"></div>
        </div>
      )}
    </main>
  );
}
