"use client";
import { useState } from 'react';
import { useRouter } from "next/navigation";

export default function Product() {
  const [formData, setFormData] = useState({ title: '', image: '', price: 0.0, stock: 0, description: '' });
  const router = useRouter();

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const saveProduct = async (e) => {
    e.preventDefault();
    try {
      const user = JSON.parse(localStorage.getItem("loginUser")) || null;
      if (!user) {
        alert("You are not logged in");
        return;
      }

      const response = await fetch('/api/products', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ ...formData, sellerId: user.id }),
      });

      if (response.ok) {
        alert('Product saved successfully');
        router.push('/productlist'); 
      } else {
        alert('Failed to save product');
      }
    } catch (error) {
      console.error(error);
      alert('Failed to save product');
    }
  };

  return (
    <main className="login-page">
      <div className="login-form-card">
        <h1 className="login-header">Add products</h1>
        <form onSubmit={saveProduct} className="login-form" id="addProductForm">
          <div className="input-container">
            <label htmlFor="title">Product Name</label>
            <input type="text" name="title" id="title" value={formData.title} onChange={handleChange} required />
          </div>
          <div className="input-container">
            <label htmlFor="image">Product Image URL</label>
            <input type="url" name="image" id="image" value={formData.image} onChange={handleChange} required />
          </div>
          <div className="input-container">
            <label htmlFor="price">Product Price</label>
            <input type="number" min="0" name="price" id="price" value={formData.price} onChange={handleChange} required />
          </div>
          <div className="input-container">
            <label htmlFor="stock">Product Stock</label>
            <input type="number" min="0" name="stock" id="stock" value={formData.stock} onChange={handleChange} required />
          </div>
          <div className="input-container">
            <label htmlFor="description">Product Description</label>
            <textarea name="description" id="description" rows="5" value={formData.description} onChange={handleChange} required></textarea>
          </div>
          <button type="submit" className="login-button product-button">Add Product</button>
        </form>
      </div>
    </main>
  );
}
